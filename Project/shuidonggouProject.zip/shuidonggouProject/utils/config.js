

class Config{
  constructor(){

  }
}

Config.requestUrl = 'https://shuidonggou88.cn/zerg/public/api/v1/'

export {Config}
