Page({
	data: {
		focus: false,
		inputValue1: '',
		inputValue2: '',
		inputValue3: '',
	},
	bindKeyInput1: function (e) {
		this.setData({
			inputValue1: e.detail.value
		})
	},
	bindKeyInput2: function (e) {
		this.setData({
			inputValue1: e.detail.value
		})
	},
	bindKeyInput3: function (e) {
		this.setData({
			inputValue1: e.detail.value
		})
	},
	save: function (e) {
		if (!this.data.inputValue1){
			this.showTips('提示', '请填写您的姓名');
			return;
		}
		if (this.data.inputValue2.lenth!=11) {
			this.showTips('提示', '请填写正确的手机号码');
			return;
		}
		if (!this.data.inputValue3) {
			this.showTips('提示', '请填写您的身份证号码');
			return;
		}

		
	},

	showTips: function (title, content, flag) {
		wx.showModal({
			title: title,
			content: content,
			showCancel: false,
			success: function (res) {
				if (flag) {
					// wx.switchTab({
					// 	url: '/pages/my/my'
					// });
				}
			}
		});
	},
})
